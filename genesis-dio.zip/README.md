# Joginho estilo Genius criado com html,css e javascript

Jogo desenvolvido durante o bootcamp da [Dio](https://www.dio.me/)


